# Beijing wsload 10k evidence

- result: PASS
- generated_at_utc: 2026-06-06T14:54:28Z
- runner_region: cn-beijing
- base_url: http://172.31.12.98:80
- ws_host: ws://172.31.12.98:80
- load_auction_id: auc_load_1780757363107911629
- target_connections: 10000
- wsload_summary: wsload-summary.json
- selected_metrics: server-metrics-window/metrics.json
- server_gate: server-gate/gate.tsv
- wsload_gate: wsload-gate/gate.tsv
- replay_verifier: replay-verifier.log

Token values are intentionally not copied into this evidence directory.
