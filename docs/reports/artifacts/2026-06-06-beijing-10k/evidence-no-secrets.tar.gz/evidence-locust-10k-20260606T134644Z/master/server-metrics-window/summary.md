# Lumen v100k metrics snapshot

- url: http://115.191.76.40/metrics
- started_at_utc: 2026-06-06T13:46:44Z
- finished_at_utc: 2026-06-06T13:50:48Z
- duration_seconds: 240
- interval_seconds: 5
- target_active_conns: 10000
- valid_samples: 35
- fetch_failures: 0
- selected_active_conns: 393
- selected_status: below_target
- selected_metrics_json: /opt/lumen-load/evidence-locust-10k-20260606T134644Z/master/server-metrics-window/metrics.json
- raw_samples_jsonl: /opt/lumen-load/evidence-locust-10k-20260606T134644Z/master/server-metrics-window/metrics-samples.jsonl

The selected metrics file is the valid sample with the highest activeConns
observed during this capture window. Feed it to:

```bash
scripts/v100k-evidence-gate.sh --metrics "/opt/lumen-load/evidence-locust-10k-20260606T134644Z/master/server-metrics-window/metrics.json" --shards <shards.tsv>
```
