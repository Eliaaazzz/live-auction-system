# Lumen v100k metrics snapshot

- url: http://127.0.0.1:80/metrics
- started_at_utc: 2026-06-06T14:31:48Z
- finished_at_utc: 2026-06-06T14:36:48Z
- duration_seconds: 300
- interval_seconds: 5
- target_active_conns: 10000
- valid_samples: 60
- fetch_failures: 0
- selected_active_conns: 10000
- selected_status: at_or_above_target
- selected_metrics_json: /opt/lumen-load/evidence-wsload-loopback80-10k-20260606T143148Z/server-metrics-window/metrics.json
- raw_samples_jsonl: /opt/lumen-load/evidence-wsload-loopback80-10k-20260606T143148Z/server-metrics-window/metrics-samples.jsonl

The selected metrics file is the valid sample with the highest activeConns
observed during this capture window. Feed it to:

```bash
scripts/v100k-evidence-gate.sh --metrics "/opt/lumen-load/evidence-wsload-loopback80-10k-20260606T143148Z/server-metrics-window/metrics.json" --shards <shards.tsv>
```
