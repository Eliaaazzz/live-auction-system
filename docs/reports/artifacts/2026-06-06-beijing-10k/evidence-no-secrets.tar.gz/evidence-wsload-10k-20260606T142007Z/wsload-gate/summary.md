# Lumen v100k evidence gate

Result: FAIL

- target_conns: 10000
- metrics_json: /opt/lumen-load/evidence-wsload-10k-20260606T142007Z/server-metrics-window/metrics.json
- shards_tsv: /opt/lumen-load/evidence-wsload-10k-20260606T142007Z/shards.tsv
- evidence_dir: /opt/lumen-load/evidence-wsload-10k-20260606T142007Z/wsload-gate
- ack_p95_max_ms: 80
- broadcast_p95_max_ms: 150
- connect_fail_rate_max: 0.001

If this result is FAIL, the honest external claim is: 10k verified; 100k not yet verified. Name the failed check before rerunning.

See gate.tsv for machine-readable checks.
