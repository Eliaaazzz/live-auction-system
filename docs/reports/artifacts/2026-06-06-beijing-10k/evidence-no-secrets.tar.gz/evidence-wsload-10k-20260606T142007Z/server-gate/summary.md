# Remote perf evidence gate

- result: FAIL
- generated_at_utc: 2026-06-06T14:26:10Z
- target_active_connections: 10000
- server_metrics: server-metrics.json
- gate: gate.tsv

## Measurement boundary

Server-side rows in gate.tsv are the only pass/fail SLO gates. Client and end-to-end metrics are retained as observed evidence only because WAN, browser, proxy, and runner delays are outside the backend SLO boundary.

## Thresholds

- ack_p95_ms <= 80
- broadcast_p95_ms <= 150
- hammer_p95_ms <= 500 when REQUIRE_HAMMER=0
- catchup_p95_ms <= 1000 when REQUIRE_CATCHUP=0
- active_connections >= 10000 unless --target 0 is used

## Server gate

```tsv
check	status	observed	op	threshold	reason
server_active_conns	FAIL	1173	>=	10000	threshold_breach
server_ack_p95_ms	PASS	0.334363	<=	80	ok
server_broadcast_p95_ms	PASS	0	<=	150	ok
server_hammer_p95_ms	PASS	0	<=	500	ok
server_catchup_p95_ms	PASS	0.766919	<=	1000	ok
server_seq_gap_count	PASS	0	==	0	ok
server_backpressure_force_close	PASS	0	==	0	ok
```
