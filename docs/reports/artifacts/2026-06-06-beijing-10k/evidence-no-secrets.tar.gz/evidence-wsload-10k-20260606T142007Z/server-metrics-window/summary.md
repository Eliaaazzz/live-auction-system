# Lumen v100k metrics snapshot

- url: http://115.191.76.40/metrics
- started_at_utc: 2026-06-06T14:20:07Z
- finished_at_utc: 2026-06-06T14:26:10Z
- duration_seconds: 360
- interval_seconds: 5
- target_active_conns: 10000
- valid_samples: 45
- fetch_failures: 1
- selected_active_conns: 1173
- selected_status: below_target
- selected_metrics_json: /opt/lumen-load/evidence-wsload-10k-20260606T142007Z/server-metrics-window/metrics.json
- raw_samples_jsonl: /opt/lumen-load/evidence-wsload-10k-20260606T142007Z/server-metrics-window/metrics-samples.jsonl

The selected metrics file is the valid sample with the highest activeConns
observed during this capture window. Feed it to:

```bash
scripts/v100k-evidence-gate.sh --metrics "/opt/lumen-load/evidence-wsload-10k-20260606T142007Z/server-metrics-window/metrics.json" --shards <shards.tsv>
```
