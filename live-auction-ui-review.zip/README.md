# 抖音直播竞拍全栈系统 · 前端（实时竞拍大师）

React + TypeScript + Vite 实现的两端前端：移动端用户端（深度还原抖音/TikTok 直播竞拍）+ PC 商家/主播管理后台（Ant Design）。设备外框复用上传的 IOSDevice / ChromeWindow 脚手架。

## 快速开始
    npm install
    npm run dev      # 打开终端给出的地址
路由：`#/` 两端同框展示 · `#/m` 移动端全屏 · `#/admin` PC 后台。
其他：`npm run build`（tsc 类型检查 + 生产构建，已通过）。无需构建的静态设计稿见根目录 design-preview.html。

## 技术栈
React 18 + TypeScript + Vite · Ant Design 5（后台，主色抖音红 #fe2c55）· react-router-dom · 模拟实时竞拍引擎 useAuctionEngine（接口与 WebSocket 一致，接后端时平替）。

## 目录结构
    src/frames/    IOSDevice.tsx · ChromeWindow.tsx
    src/lib/       types · format · mockData · assets(真实素材) · sound(Web Audio音效) · useAuctionEngine
    src/mobile/    MobileApp · LiveRoom · components · icons(SVG图标) · tabs · BidSheet · overlays · mobile.css · motion.css
    src/admin/     AdminApp + pages(Dashboard · ProductManage · AuctionPublish · OrderManage · LiveMonitor)

## 移动端要点
全屏真实视频铺底，UI 全部浮层叠加。5 个底部 Tab（点击弹起 sheet，默认收起）：概览(第一/二名/我的排名/与第一差距) · 历史(最近3条+横滑) · 评论 · 我要参与(签署绑定条款+冻结保证金 → 拍卖：固定档位/自定义/自动出价上限) · 规则。第一名锁定加固、第二名反超推荐。完整状态机：即将开拍→竞拍中→截拍中(毫秒倒计时+自动延时)→成交(我赢=支付/他人赢=落槌)/流拍。上滑切换直播间；拉流/卡住统一骨架屏。

## PC 后台要点
侧边导航：数据概览 · 竞拍发布(规则配置+移动端预览) · 直播商品(复刻 spec 列表：起拍价/固定加价/封顶价/当前出价/出价次数/倒计时/上下架/讲解/取消异常竞拍) · 订单管理 · 实时竞拍监控(状态机/出价流水/排行榜/异常取消)。

## 参考平台
TikTok Countdown Bidding（竞拍叠加直播视频、Fixed/Extended 计时、自动出价上限、实名+绑卡+保证金参与）· Whatnot（常驻倒计时、每次出价延长、sudden death）· 微拍堂（加价抢拍/保证金/鉴定）· 抖音参考稿（1:1 还原各界面）。

## UI/UX 升级（v2 · 去 AI 味）
真实图片素材（Unsplash 拍品图 + pravatar 真实头像，集中于 src/lib/assets.ts，带 onError 兜底）· 线性 SVG 图标替代 emoji（src/mobile/icons.tsx）· 底部 Tab 点击弹起 sheet · 更克制的视觉。

## 紧张竞拍氛围 · 动效 + 音效（v3）
src/lib/sound.ts 用 Web Audio API 合成全部音效（无音频文件、可离线），src/mobile/motion.css 配套微动画，由竞拍引擎事件统一驱动：
- 新出价 → 轻快滴声 + 价格跳动 + 金额 +¥X 上飘
- 我领先 → 上行三音 + 金色全屏一闪
- 被超越 → 下行刺耳音 + 红闪 + 出价条抖动
- 自动延时 → 双声提示
- 截拍中 → 每秒滴答（最后5s急促）+ 全屏红色脉冲暗角 + 倒计时数字猛跳
- 落槌成交 → 低频闷响（我赢→上行琶音 + 撒花）· 流拍 → 低落两音
右上角一键静音（持久化）；浏览器策略要求首次交互后解锁音频，已在首次点击自动解锁。

## 接入真实后端
把 useAuctionEngine 内部定时器替换为 WebSocket 订阅：服务端推送出价事件 → 更新同一份 AuctionState 快照；placeBid 改为发送出价并等 ACK（乐观锁校验 + 房间级路由隔离）。UI 全部基于 AuctionState，无需改动。
